#include "tailored_list.h"

void modify_list(Node **const pt_to_pt_to_node, const int);
